import { useEffect, useRef } from 'react'

interface Node {
  x: number
  y: number
}

// A deterministic "orchestration graph": nodes connected by edges, with
// pulses of light traveling along the edges like data moving through a
// pipeline. This is the site's signature element — a literal picture of
// what SEVEN-MOTION builds: systems that route signal through a graph.
export default function SignalFlow({ density = 1 }: { density?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches

    let width = 0
    let height = 0
    let dpr = Math.min(window.devicePixelRatio || 1, 2)
    let nodes: Node[] = []
    let edges: [number, number][] = []
    let pulses: { edge: number; t: number; speed: number }[] = []
    let raf = 0

    function layout() {
      const rect = canvas!.getBoundingClientRect()
      width = rect.width
      height = rect.height
      dpr = Math.min(window.devicePixelRatio || 1, 2)
      canvas!.width = width * dpr
      canvas!.height = height * dpr
      ctx!.scale(dpr, dpr)

      const cols = Math.max(5, Math.round((width / 130) * density))
      const rows = Math.max(3, Math.round((height / 130) * density))
      nodes = []
      for (let i = 0; i < cols; i++) {
        for (let j = 0; j < rows; j++) {
          const jitter = 26
          nodes.push({
            x: (i + 0.5) * (width / cols) + (Math.sin(i * 12.9 + j * 7.1) * jitter),
            y: (j + 0.5) * (height / rows) + (Math.cos(j * 9.3 + i * 4.7) * jitter),
          })
        }
      }

      edges = []
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x
          const dy = nodes[i].y - nodes[j].y
          const dist = Math.sqrt(dx * dx + dy * dy)
          if (dist < width / cols + 20 && Math.random() > 0.35) {
            edges.push([i, j])
          }
        }
      }

      pulses = []
      const pulseCount = Math.round(edges.length * 0.35)
      for (let i = 0; i < pulseCount; i++) {
        pulses.push({
          edge: Math.floor(Math.random() * edges.length),
          t: Math.random(),
          speed: 0.0025 + Math.random() * 0.004,
        })
      }
    }

    function draw() {
      ctx!.clearRect(0, 0, width, height)

      // edges
      ctx!.lineWidth = 1
      ctx!.strokeStyle = 'rgba(140, 148, 180, 0.08)'
      edges.forEach(([a, b]) => {
        ctx!.beginPath()
        ctx!.moveTo(nodes[a].x, nodes[a].y)
        ctx!.lineTo(nodes[b].x, nodes[b].y)
        ctx!.stroke()
      })

      // nodes
      nodes.forEach((n) => {
        ctx!.beginPath()
        ctx!.arc(n.x, n.y, 1.4, 0, Math.PI * 2)
        ctx!.fillStyle = 'rgba(180, 186, 210, 0.35)'
        ctx!.fill()
      })

      // pulses
      pulses.forEach((p) => {
        const [a, b] = edges[p.edge]
        if (!a && a !== 0) return
        const na = nodes[a]
        const nb = nodes[b]
        if (!na || !nb) return
        const x = na.x + (nb.x - na.x) * p.t
        const y = na.y + (nb.y - na.y) * p.t

        const grad = ctx!.createRadialGradient(x, y, 0, x, y, 10)
        grad.addColorStop(0, 'rgba(124, 92, 252, 0.9)')
        grad.addColorStop(0.5, 'rgba(35, 229, 219, 0.35)')
        grad.addColorStop(1, 'rgba(35, 229, 219, 0)')
        ctx!.beginPath()
        ctx!.arc(x, y, 10, 0, Math.PI * 2)
        ctx!.fillStyle = grad
        ctx!.fill()

        ctx!.beginPath()
        ctx!.arc(x, y, 1.8, 0, Math.PI * 2)
        ctx!.fillStyle = '#e9f9f8'
        ctx!.fill()

        if (!prefersReduced) {
          p.t += p.speed
          if (p.t > 1) {
            p.t = 0
            p.edge = Math.floor(Math.random() * edges.length)
          }
        }
      })

      raf = requestAnimationFrame(draw)
    }

    layout()
    draw()

    const onResize = () => {
      cancelAnimationFrame(raf)
      layout()
    }
    window.addEventListener('resize', onResize)

    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', onResize)
    }
  }, [density])

  return <canvas ref={canvasRef} className="w-full h-full block" aria-hidden="true" />
}
