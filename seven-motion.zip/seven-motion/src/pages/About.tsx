import { ArrowUpRight } from 'lucide-react'
import Reveal from '../components/Reveal'
import { Link } from 'react-router-dom'

const principles = [
  {
    title: 'Ship the system, not the demo',
    body: 'A workflow that only works in a sandbox isn\u2019t done. Every project here runs against real data, real APIs, and real failure modes \u2014 Shopify webhooks that fire out of order, charts that render slow, rate limits that hit at the worst time.',
  },
  {
    title: 'Autonomy needs an audit trail',
    body: 'AI that acts on its own is only trustworthy if you can see why it acted. Decision logging and attribution aren\u2019t an afterthought \u2014 they\u2019re what turns "the AI did it" into a process a business can actually rely on.',
  },
  {
    title: 'Own the whole stack',
    body: 'Frontend, backend, infra, and the AI layer in between. Fewer handoffs means fewer places for a system to quietly break.',
  },
]

export default function About() {
  return (
    <div className="pt-32 pb-24">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
          <div className="lg:col-span-7">
            <Reveal>
              <p className="font-mono text-xs text-dim uppercase tracking-wider mb-3">About</p>
            </Reveal>
            <Reveal delay={0.05}>
              <h1 className="font-display text-4xl sm:text-5xl font-semibold tracking-tight leading-[1.05]">
                Seven Motion is a one-person studio with a simple thesis:
                <span className="text-gradient"> software should run itself.</span>
              </h1>
            </Reveal>

            <Reveal delay={0.12}>
              <div className="mt-9 space-y-5 text-muted leading-relaxed text-[15px]">
                <p>
                  I'm the founder and sole engineer behind Seven Motion \u2014 an AI SaaS
                  engineer building systems that make decisions and take action, not
                  just systems that display data.
                </p>
                <p>
                  My work sits at the intersection of two things that don't usually
                  get built by the same person: production-grade software engineering,
                  and applied AI that's wired directly into a business's real
                  operations. That combination shows up across everything I ship \u2014
                  an eCommerce operating system that attributes revenue to the exact
                  automation that produced it, a market-orchestration engine that
                  reads charts visually instead of hitting a rate-limited API, and
                  marketing agents that leave a traceable decision log instead of a
                  black box.
                </p>
                <p>
                  Every one of these started as a real operational problem, not a
                  portfolio idea \u2014 which is why they're built to survive contact with
                  production traffic, not just a demo call.
                </p>
              </div>
            </Reveal>

            <Reveal delay={0.2}>
              <div className="mt-10 flex flex-wrap gap-3">
                <a
                  href="https://github.com/SEVEN-MOTION"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 font-mono text-sm border border-border-hi rounded-full px-5 py-3 hover:border-cyan hover:text-cyan transition-colors"
                >
                  github.com/SEVEN-MOTION <ArrowUpRight size={14} />
                </a>
                <Link
                  to="/contact"
                  className="inline-flex items-center gap-2 font-mono text-sm bg-text text-bg rounded-full px-5 py-3 hover:bg-cyan transition-colors"
                >
                  Get in touch <ArrowUpRight size={14} />
                </Link>
              </div>
            </Reveal>
          </div>

          <div className="lg:col-span-5">
            <Reveal delay={0.15} className="lg:sticky lg:top-28">
              <div className="rounded-2xl border border-border bg-surface/40 p-8">
                <p className="font-mono text-xs text-dim uppercase tracking-wider mb-5">Currently</p>
                <p className="font-display text-xl font-medium mb-1">AI SaaS Engineer</p>
                <p className="text-muted text-sm mb-8">Founder, Seven Motion</p>

                <div className="h-px bg-border mb-8" />

                <p className="font-mono text-xs text-dim uppercase tracking-wider mb-4">Core stack</p>
                <div className="flex flex-wrap gap-2">
                  {['TypeScript', 'React', 'Node.js', 'Firebase', 'Playwright', 'Gemini', 'Shopify Admin API', 'Tailwind CSS'].map((s) => (
                    <span key={s} className="font-mono text-[11px] text-muted border border-border rounded-full px-2.5 py-1">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 mt-28">
        <Reveal>
          <p className="font-mono text-xs text-dim uppercase tracking-wider mb-3">How I build</p>
        </Reveal>
        <Reveal delay={0.05}>
          <h2 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight mb-14">
            Three principles, applied every time.
          </h2>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {principles.map((p, i) => (
            <Reveal key={p.title} delay={i * 0.08} className="border-t border-border pt-7">
              <span className="font-mono text-xs text-violet">0{i + 1}</span>
              <h3 className="font-display text-lg font-medium mt-4 mb-3">{p.title}</h3>
              <p className="text-muted text-sm leading-relaxed">{p.body}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </div>
  )
}
