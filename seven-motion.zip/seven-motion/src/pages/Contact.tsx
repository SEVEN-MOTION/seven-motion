import { useState, type FormEvent } from 'react'
import { ArrowUpRight, Check } from 'lucide-react'
import Reveal from '../components/Reveal'

const budgets = ['< $5k', '$5k \u2013 $15k', '$15k \u2013 $50k', '$50k+']

export default function Contact() {
  const [budget, setBudget] = useState<string | null>(null)
  const [sent, setSent] = useState(false)

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    // No backend is wired up yet \u2014 swap this for a real endpoint
    // (Formspree, Resend, a Cloudflare Worker, etc.) before going live.
    setSent(true)
  }

  return (
    <div className="pt-32 pb-24 min-h-screen">
      <div className="max-w-6xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-14">
        <div className="lg:col-span-5">
          <Reveal>
            <p className="font-mono text-xs text-dim uppercase tracking-wider mb-3">Contact</p>
          </Reveal>
          <Reveal delay={0.05}>
            <h1 className="font-display text-4xl sm:text-5xl font-semibold tracking-tight leading-[1.05]">
              Let's build something that runs without you.
            </h1>
          </Reveal>
          <Reveal delay={0.12}>
            <p className="text-muted mt-6 leading-relaxed max-w-md">
              Whether it's an AI operating system, an automation engine, or
              something in between \u2014 tell me the problem and I'll tell you
              honestly whether it's worth automating.
            </p>
          </Reveal>

          <Reveal delay={0.2} className="mt-10 space-y-4">
            <a
              href="https://github.com/SEVEN-MOTION"
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-between border border-border rounded-xl px-5 py-4 hover:border-cyan transition-colors group"
            >
              <div>
                <p className="font-mono text-xs text-dim mb-1">GitHub</p>
                <p className="text-sm">github.com/SEVEN-MOTION</p>
              </div>
              <ArrowUpRight size={16} className="text-dim group-hover:text-cyan transition-colors" />
            </a>
            <a
              href="https://glowify-ai-system.vercel.app"
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-between border border-border rounded-xl px-5 py-4 hover:border-cyan transition-colors group"
            >
              <div>
                <p className="font-mono text-xs text-dim mb-1">Live product</p>
                <p className="text-sm">Glowify AI Dashboard</p>
              </div>
              <ArrowUpRight size={16} className="text-dim group-hover:text-cyan transition-colors" />
            </a>
          </Reveal>
        </div>

        <div className="lg:col-span-7">
          <Reveal delay={0.1}>
            <div className="rounded-2xl border border-border bg-surface/40 p-8 sm:p-10">
              {sent ? (
                <div className="py-16 flex flex-col items-center text-center">
                  <div className="w-14 h-14 rounded-full bg-cyan/10 border border-cyan/30 flex items-center justify-center mb-6">
                    <Check size={22} className="text-cyan" />
                  </div>
                  <h2 className="font-display text-2xl font-semibold mb-2">Message queued.</h2>
                  <p className="text-muted max-w-xs">
                    Thanks for reaching out \u2014 I'll get back to you shortly.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <Field label="Name" name="name" placeholder="Jane Founder" />
                    <Field label="Email" name="email" type="email" placeholder="jane@company.com" />
                  </div>
                  <Field label="Company" name="company" placeholder="Company (optional)" required={false} />

                  <div>
                    <label className="font-mono text-xs text-dim uppercase tracking-wider block mb-3">
                      Project budget
                    </label>
                    <div className="flex flex-wrap gap-2.5">
                      {budgets.map((b) => (
                        <button
                          type="button"
                          key={b}
                          onClick={() => setBudget(b)}
                          className={`font-mono text-xs rounded-full px-4 py-2 border transition-colors ${
                            budget === b
                              ? 'border-cyan text-cyan bg-cyan/5'
                              : 'border-border text-muted hover:border-border-hi hover:text-text'
                          }`}
                        >
                          {b}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label htmlFor="message" className="font-mono text-xs text-dim uppercase tracking-wider block mb-2">
                      Project details
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      required
                      rows={5}
                      placeholder="What needs to run itself?"
                      className="w-full bg-bg border border-border rounded-xl px-4 py-3.5 text-sm text-text placeholder:text-dim focus:border-cyan outline-none transition-colors resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-text text-bg font-medium px-7 py-3.5 rounded-full hover:bg-cyan transition-colors"
                  >
                    Send message
                    <ArrowUpRight size={16} />
                  </button>
                </form>
              )}
            </div>
          </Reveal>
        </div>
      </div>
    </div>
  )
}

function Field({
  label,
  name,
  type = 'text',
  placeholder,
  required = true,
}: {
  label: string
  name: string
  type?: string
  placeholder: string
  required?: boolean
}) {
  return (
    <div>
      <label htmlFor={name} className="font-mono text-xs text-dim uppercase tracking-wider block mb-2">
        {label}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        required={required}
        placeholder={placeholder}
        className="w-full bg-bg border border-border rounded-xl px-4 py-3.5 text-sm text-text placeholder:text-dim focus:border-cyan outline-none transition-colors"
      />
    </div>
  )
}
