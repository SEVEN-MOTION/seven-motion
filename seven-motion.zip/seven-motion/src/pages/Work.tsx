import { ArrowUpRight } from 'lucide-react'
import Reveal from '../components/Reveal'
import { projects } from '../data/projects'

export default function Work() {
  return (
    <div className="pt-32 pb-24">
      <div className="max-w-6xl mx-auto px-6">
        <Reveal>
          <p className="font-mono text-xs text-dim uppercase tracking-wider mb-3">Work</p>
        </Reveal>
        <Reveal delay={0.05}>
          <h1 className="font-display text-4xl sm:text-6xl font-semibold tracking-tight max-w-2xl">
            Three systems. Three different problems. One approach.
          </h1>
        </Reveal>
        <Reveal delay={0.1}>
          <p className="text-muted mt-6 max-w-xl leading-relaxed">
            Every project below is pulled straight from{' '}
            <a href="https://github.com/SEVEN-MOTION" target="_blank" rel="noreferrer" className="text-cyan hover:underline underline-offset-4">
              github.com/SEVEN-MOTION
            </a>
            . No mockups, no "coming soon" — this is what shipped.
          </p>
        </Reveal>
      </div>

      <div className="max-w-6xl mx-auto px-6 mt-20 space-y-24">
        {projects.map((p, i) => (
          <Reveal key={p.slug}>
            <article className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-start border-t border-border pt-12">
              <div className="lg:col-span-4">
                <span className="font-mono text-6xl text-surface-2 font-semibold select-none block leading-none">
                  {String(i + 1).padStart(2, '0')}
                </span>
                <p className="font-mono text-xs text-violet mt-6 mb-2">{p.category} · {p.year}</p>
                <h2 className="font-display text-3xl font-semibold tracking-tight">{p.name}</h2>
                <p className="text-muted mt-2 text-sm">{p.tagline}</p>

                <div className="flex flex-wrap gap-2 mt-6">
                  {p.stack.map((s) => (
                    <span key={s} className="font-mono text-[11px] text-muted border border-border rounded-full px-2.5 py-1">
                      {s}
                    </span>
                  ))}
                </div>

                <div className="flex flex-wrap gap-3 mt-7">
                  <a
                    href={p.href}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 font-mono text-sm text-text border border-border-hi rounded-full px-4 py-2 hover:border-cyan hover:text-cyan transition-colors"
                  >
                    Repository <ArrowUpRight size={14} />
                  </a>
                  {p.live && (
                    <a
                      href={p.live}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 font-mono text-sm text-bg bg-cyan rounded-full px-4 py-2 hover:bg-text transition-colors"
                    >
                      Live app <ArrowUpRight size={14} />
                    </a>
                  )}
                </div>
              </div>

              <div className="lg:col-span-8">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-px bg-border rounded-xl overflow-hidden border border-border mb-8">
                  {p.metrics.map((m) => (
                    <div key={m.label} className="bg-surface/50 p-5">
                      <p className="font-mono text-[10px] text-dim uppercase tracking-wider mb-1.5">{m.label}</p>
                      <p className="text-sm text-text font-medium leading-snug">{m.value}</p>
                    </div>
                  ))}
                </div>

                <div className="space-y-5">
                  {p.description.map((para, idx) => (
                    <p key={idx} className="text-muted leading-relaxed">
                      {para}
                    </p>
                  ))}
                </div>
              </div>
            </article>
          </Reveal>
        ))}
      </div>
    </div>
  )
}
