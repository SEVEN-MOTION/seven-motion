import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer className="border-t border-border">
      <div className="max-w-6xl mx-auto px-6 py-14 grid grid-cols-1 md:grid-cols-[1.4fr_1fr_1fr] gap-10">
        <div>
          <div className="flex items-center gap-2 mb-4">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan" />
            <span className="font-display font-semibold tracking-tight">SEVEN-MOTION</span>
          </div>
          <p className="text-muted text-sm max-w-xs leading-relaxed">
            AI SaaS engineering studio. Building autonomous systems for
            commerce and markets — shipped, not slideware.
          </p>
        </div>

        <div className="font-mono text-sm">
          <p className="text-dim uppercase tracking-wider text-xs mb-4">Site</p>
          <ul className="space-y-2.5 text-muted">
            <li><Link to="/" className="hover:text-cyan transition-colors">Home</Link></li>
            <li><Link to="/work" className="hover:text-cyan transition-colors">Work</Link></li>
            <li><Link to="/about" className="hover:text-cyan transition-colors">About</Link></li>
            <li><Link to="/contact" className="hover:text-cyan transition-colors">Contact</Link></li>
          </ul>
        </div>

        <div className="font-mono text-sm">
          <p className="text-dim uppercase tracking-wider text-xs mb-4">Elsewhere</p>
          <ul className="space-y-2.5 text-muted">
            <li>
              <a href="https://github.com/SEVEN-MOTION" target="_blank" rel="noreferrer" className="hover:text-cyan transition-colors">
                GitHub ↗
              </a>
            </li>
            <li>
              <a href="https://glowify-ai-system.vercel.app" target="_blank" rel="noreferrer" className="hover:text-cyan transition-colors">
                Glowify AI (live) ↗
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 pb-10 flex flex-col sm:flex-row justify-between gap-2 text-dim text-xs font-mono">
        <span>© {new Date().getFullYear()} Seven Motion. Shipping scalable software.</span>
        <span>Built with React · Motion · Tailwind</span>
      </div>
    </footer>
  )
}
