# SEVEN-MOTION

Portfolio site for Seven Motion — an AI SaaS engineering studio. Built with
React, TypeScript, Vite, Tailwind CSS v4, and Motion (Framer Motion),
showcasing real projects pulled from [github.com/SEVEN-MOTION](https://github.com/SEVEN-MOTION).

## Develop

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

Outputs a static site to `dist/`.

## Deploy

**Vercel:** import this repo — `vercel.json` already handles SPA routing.
Framework preset: Vite.

**Cloudflare Pages:** connect the repo.
- Build command: `npm run build`
- Build output directory: `dist`
`public/_redirects` handles SPA routing.

## Editing content

- Project data (the Work page + featured work on Home) lives in
  `src/data/projects.ts` — edit or add entries there.
- Contact form in `src/pages/Contact.tsx` currently has no backend wired up.
  Wire `handleSubmit` to a real endpoint (Formspree, Resend via a Cloudflare
  Worker, etc.) before relying on it in production.
