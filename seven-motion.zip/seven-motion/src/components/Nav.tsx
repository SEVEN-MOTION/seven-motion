import { useEffect, useState } from 'react'
import { NavLink } from 'react-router-dom'
import { motion } from 'motion/react'

const links = [
  { to: '/', label: 'Home' },
  { to: '/work', label: 'Work' },
  { to: '/about', label: 'About' },
  { to: '/contact', label: 'Contact' },
]

export default function Nav() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    onScroll()
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-colors duration-300 ${
        scrolled ? 'bg-bg/85 backdrop-blur-md border-b border-border' : 'bg-transparent border-b border-transparent'
      }`}
    >
      <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <NavLink to="/" className="flex items-center gap-2 group" onClick={() => setOpen(false)}>
          <span className="relative w-2.5 h-2.5 rounded-full bg-cyan">
            <span className="absolute inset-0 rounded-full bg-cyan animate-ping opacity-60" />
          </span>
          <span className="font-display font-semibold tracking-tight text-[15px]">
            SEVEN<span className="text-dim">-</span>MOTION
          </span>
        </NavLink>

        <nav className="hidden md:flex items-center gap-1 font-mono text-[13px]">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.to === '/'}
              className={({ isActive }) =>
                `px-4 py-2 rounded-full transition-colors ${
                  isActive ? 'text-text bg-surface-2' : 'text-muted hover:text-text'
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
          <a
            href="https://github.com/SEVEN-MOTION"
            target="_blank"
            rel="noreferrer"
            className="ml-2 px-4 py-2 rounded-full border border-border-hi text-text hover:border-cyan hover:text-cyan transition-colors"
          >
            GitHub ↗
          </a>
        </nav>

        <button
          className="md:hidden text-text w-9 h-9 flex flex-col items-center justify-center gap-1.5"
          aria-label="Toggle menu"
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          <span className={`block w-5 h-px bg-text transition-transform ${open ? 'translate-y-[3px] rotate-45' : ''}`} />
          <span className={`block w-5 h-px bg-text transition-opacity ${open ? 'opacity-0' : ''}`} />
          <span className={`block w-5 h-px bg-text transition-transform ${open ? '-translate-y-[3px] -rotate-45' : ''}`} />
        </button>
      </div>

      {open && (
        <motion.nav
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          className="md:hidden border-t border-border bg-bg font-mono text-sm"
        >
          <div className="flex flex-col px-6 py-4 gap-1">
            {links.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.to === '/'}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  `py-2.5 ${isActive ? 'text-cyan' : 'text-muted'}`
                }
              >
                {l.label}
              </NavLink>
            ))}
            <a href="https://github.com/SEVEN-MOTION" target="_blank" rel="noreferrer" className="py-2.5 text-muted">
              GitHub ↗
            </a>
          </div>
        </motion.nav>
      )}
    </header>
  )
}
