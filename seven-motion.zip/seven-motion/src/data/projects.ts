export interface Project {
  slug: string
  name: string
  tagline: string
  summary: string
  description: string[]
  stack: string[]
  category: string
  year: string
  href: string
  live?: string
  featured?: boolean
  metrics: { label: string; value: string }[]
}

export const projects: Project[] = [
  {
    slug: 'glowify-ai',
    name: 'Glowify AI',
    tagline: 'The command center for AI-run commerce',
    summary:
      'A premium AI-powered operating system for Shopify beauty brands — centralizing marketing, automation, analytics, and customer intelligence into one real-time control surface.',
    description: [
      'Glowify AI replaces the spreadsheet-and-dashboard sprawl that D2C teams live in with a single executive layer: one surface that watches revenue, ad spend, inventory health, and customer retention at the same time, and tells the operator what actually needs a decision today.',
      'The system synchronizes with Shopify, Meta, Google, and Klaviyo in real time through Firebase Cloud Functions, scoring the health of every active automation and attributing revenue back to the workflow that produced it — so "AI automation" stops being a black box and starts being an audit trail.',
      'Built as a production Vite + React monorepo with a typed data layer, it ships with its own margin analysis engine, retention-curve tracking, and a bundling-opportunity model that reads SKU-level data instead of guessing.',
    ],
    stack: ['React', 'TypeScript', 'Vite', 'Tailwind CSS v4', 'Firebase', 'Cloud Functions', 'Recharts', 'Shopify Admin API'],
    category: 'AI Commerce OS',
    year: '2026',
    href: 'https://github.com/SEVEN-MOTION/Glowify-ai-system',
    live: 'https://glowify-ai-system.vercel.app',
    featured: true,
    metrics: [
      { label: 'Integrations', value: 'Shopify · Meta · Google · Klaviyo' },
      { label: 'Core module', value: 'Real-time attribution engine' },
      { label: 'Stack depth', value: '87 commits, full audit trail' },
    ],
  },
  {
    slug: 'shadowchart-ai',
    name: 'SHADOWCHART-AI',
    tagline: 'A market orchestration engine that watches, not queries',
    summary:
      'An institutional-grade, multi-modal engine that reads live market charts the way a quant analyst does — visually — and streams back mechanically executable trade bands.',
    description: [
      'Most trading tools hit an API and hope the rate limit holds. SHADOWCHART-AI takes a different position: it drives a stealth-hardened Playwright browser to render charts exactly as a human would see them, then hands high-density canvas frames to a Gemini multimodal vision pipeline for structural analysis.',
      'From there it calculates dynamic Volume Profile Delta anomalies and converts them into rigid, mechanically executable trade bands — output that a downstream system can act on without a human re-interpreting a chart at 2am.',
      'The result is a system that scales past traditional API ceilings by treating the chart itself as the data source, containerized end-to-end for unattended, always-on operation.',
    ],
    stack: ['Node.js', 'TypeScript', 'Playwright Stealth', 'Gemini Vision', 'pnpm', 'Docker'],
    category: 'Quant Infrastructure',
    year: '2026',
    href: 'https://github.com/SEVEN-MOTION/SHADOWCHART-AI',
    featured: true,
    metrics: [
      { label: 'Ingestion', value: 'Multimodal chart vision' },
      { label: 'Output', value: 'Executable trade bands' },
      { label: 'Runtime', value: 'Containerized, unattended' },
    ],
  },
  {
    slug: 'shopify-marketing-ai-ii',
    name: 'Shopify Marketing AI II',
    tagline: 'Agents that run the marketing calendar',
    summary:
      'A multi-agent system that plans, writes, and manages Shopify marketing autonomously — turning a store\'s catalog and performance data into ongoing campaign execution.',
    description: [
      'Where Glowify AI is the dashboard, this is the engine underneath it: a set of coordinated AI agents that take store and campaign data as input and produce marketing actions as output, with a human able to step in at any checkpoint.',
      'It was built as the second iteration of an earlier automation system — the rebuild focused on making agent decisions traceable, so growth teams can see why a campaign ran, not just that it did.',
    ],
    stack: ['TypeScript', 'AI Agents', 'Shopify Admin API'],
    category: 'Marketing Automation',
    year: '2025',
    href: 'https://github.com/SEVEN-MOTION/shopify-marketing-ai-ii',
    metrics: [
      { label: 'Model', value: 'Multi-agent orchestration' },
      { label: 'Iteration', value: 'v2 rebuild, traceable decisions' },
    ],
  },
]

export const featuredProjects = projects.filter((p) => p.featured)
