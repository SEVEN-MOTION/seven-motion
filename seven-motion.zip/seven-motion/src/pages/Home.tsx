import { Link } from 'react-router-dom'
import { motion } from 'motion/react'
import { ArrowUpRight } from 'lucide-react'
import SignalFlow from '../components/SignalFlow'
import Reveal from '../components/Reveal'
import { featuredProjects } from '../data/projects'

const capabilities = [
  {
    label: 'Orchestration',
    detail: 'Multi-service systems that sync Shopify, Firebase, and ad platforms into one live state.',
  },
  {
    label: 'AI Agents',
    detail: 'Agentic workflows that plan, act, and leave a traceable decision log — not a black box.',
  },
  {
    label: 'Vision Pipelines',
    detail: 'Multimodal ingestion that reads charts, screens, and UI the way a human analyst would.',
  },
  {
    label: 'Shipping',
    detail: 'Production TypeScript, CI-tested, deployed on Vercel — not a proof of concept.',
  },
]

export default function Home() {
  return (
    <div>
      {/* Hero */}
      <section className="relative min-h-[92vh] flex items-center overflow-hidden border-b border-border">
        <div className="absolute inset-0 opacity-70">
          <SignalFlow density={1} />
        </div>
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              'radial-gradient(60% 50% at 50% 38%, transparent 0%, var(--color-bg) 78%), linear-gradient(180deg, transparent 60%, var(--color-bg) 100%)',
          }}
        />

        <div className="relative max-w-6xl mx-auto px-6 pt-24 pb-20 w-full">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 font-mono text-xs text-cyan border border-cyan/25 bg-cyan/5 rounded-full px-3 py-1.5 mb-8"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-cyan animate-pulse" />
            AI SaaS Engineer — Founder @ Seven Motion
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="font-display font-semibold tracking-tight text-[clamp(2.6rem,8vw,4.6rem)] leading-[0.98] max-w-4xl"
          >
            We build the <span className="text-gradient">machines</span> that run the business.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.22, ease: [0.16, 1, 0.3, 1] }}
            className="mt-7 text-muted text-lg max-w-xl leading-relaxed"
          >
            Seven Motion designs and ships autonomous software — commerce
            operating systems, market-orchestration engines, and AI agents
            that make decisions and leave a paper trail. Production code,
            not a pitch deck.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.34, ease: [0.16, 1, 0.3, 1] }}
            className="mt-10 flex flex-wrap items-center gap-4"
          >
            <Link
              to="/work"
              className="group inline-flex items-center gap-2 bg-text text-bg font-medium px-6 py-3.5 rounded-full hover:bg-cyan transition-colors"
            >
              See the work
              <ArrowUpRight size={16} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </Link>
            <a
              href="https://github.com/SEVEN-MOTION"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 font-mono text-sm text-muted hover:text-text transition-colors px-2 py-3.5"
            >
              github.com/SEVEN-MOTION ↗
            </a>
          </motion.div>
        </div>
      </section>

      {/* Capabilities */}
      <section className="max-w-6xl mx-auto px-6 py-24 border-b border-border">
        <Reveal>
          <p className="font-mono text-xs text-dim uppercase tracking-wider mb-3">What we build</p>
        </Reveal>
        <Reveal delay={0.05}>
          <h2 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight max-w-2xl">
            Systems that act, not dashboards that watch.
          </h2>
        </Reveal>

        <div className="mt-14 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-px bg-border rounded-2xl overflow-hidden border border-border">
          {capabilities.map((c, i) => (
            <Reveal key={c.label} delay={i * 0.06} className="bg-bg p-7 h-full">
              <span className="font-mono text-xs text-violet">0{i + 1}</span>
              <h3 className="font-display text-lg font-medium mt-4 mb-2.5">{c.label}</h3>
              <p className="text-muted text-sm leading-relaxed">{c.detail}</p>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Featured work */}
      <section className="max-w-6xl mx-auto px-6 py-24">
        <div className="flex items-end justify-between mb-14 gap-6 flex-wrap">
          <div>
            <Reveal>
              <p className="font-mono text-xs text-dim uppercase tracking-wider mb-3">Selected work</p>
            </Reveal>
            <Reveal delay={0.05}>
              <h2 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight">
                Shipped, running, load-bearing.
              </h2>
            </Reveal>
          </div>
          <Reveal delay={0.1}>
            <Link to="/work" className="font-mono text-sm text-cyan hover:underline underline-offset-4 whitespace-nowrap">
              View all work →
            </Link>
          </Reveal>
        </div>

        <div className="grid grid-cols-1 gap-6">
          {featuredProjects.map((p, i) => (
            <Reveal key={p.slug} delay={i * 0.08}>
              <a
                href={p.href}
                target="_blank"
                rel="noreferrer"
                className="group block rounded-2xl border border-border hover:border-border-hi bg-surface/40 p-8 sm:p-10 transition-colors relative overflow-hidden"
              >
                <div
                  className="absolute -top-24 -right-24 w-72 h-72 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-3xl"
                  style={{ background: 'radial-gradient(circle, var(--color-violet), transparent 70%)' }}
                />
                <div className="relative flex flex-col md:flex-row md:items-start justify-between gap-8">
                  <div className="max-w-xl">
                    <div className="flex items-center gap-3 mb-4 font-mono text-xs text-dim">
                      <span className="text-violet">{p.category}</span>
                      <span>·</span>
                      <span>{p.year}</span>
                    </div>
                    <h3 className="font-display text-2xl sm:text-3xl font-semibold tracking-tight flex items-center gap-2">
                      {p.name}
                      <ArrowUpRight size={20} className="text-dim group-hover:text-cyan group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
                    </h3>
                    <p className="text-muted mt-3 leading-relaxed">{p.summary}</p>
                  </div>

                  <div className="flex flex-wrap gap-2 md:max-w-[220px] md:justify-end">
                    {p.stack.slice(0, 4).map((s) => (
                      <span key={s} className="font-mono text-[11px] text-muted border border-border rounded-full px-2.5 py-1">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
              </a>
            </Reveal>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-border">
        <div className="max-w-6xl mx-auto px-6 py-24 text-center">
          <Reveal>
            <h2 className="font-display text-3xl sm:text-5xl font-semibold tracking-tight max-w-2xl mx-auto">
              Have something worth automating?
            </h2>
          </Reveal>
          <Reveal delay={0.08}>
            <p className="text-muted mt-5 max-w-md mx-auto">
              Tell me what the system needs to do. I'll tell you what it takes to build it right.
            </p>
          </Reveal>
          <Reveal delay={0.16}>
            <Link
              to="/contact"
              className="mt-9 inline-flex items-center gap-2 bg-text text-bg font-medium px-7 py-3.5 rounded-full hover:bg-cyan transition-colors"
            >
              Start a conversation
              <ArrowUpRight size={16} />
            </Link>
          </Reveal>
        </div>
      </section>
    </div>
  )
}
